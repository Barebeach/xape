




async function processVoiceCommand(command, skillbarInstance) {
  console.log(`🎤 Processing voice command: "${command}"`)
  
  
  
  
  
  
  
  
  console.log('⚠️ processVoiceCommand is still in main class (too complex to extract safely)')
}


window.processVoiceCommand = processVoiceCommand

















